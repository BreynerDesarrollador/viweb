<p class="alert alert-info">
	is simply dummy text  
</p>